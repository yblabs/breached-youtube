"""BREACHED YOUTUBE — FastAPI surface: metadata, download jobs, websocket progress."""

from __future__ import annotations

import asyncio
import shutil
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import engine
from .jobs import TERMINAL_STATUSES, JobManager

BASE_DIR = Path(__file__).resolve().parent.parent
DOWNLOAD_DIR = BASE_DIR / "downloads"
FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"

manager = JobManager(DOWNLOAD_DIR)


@asynccontextmanager
async def lifespan(_: FastAPI):
    manager.start()
    yield
    await manager.stop()


app = FastAPI(
    title="BREACHED YOUTUBE API",
    description="Cyberpunk YouTube stream extraction pipeline (yt-dlp + ffmpeg). Made by Yash & Bhupesh.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------------------------------
# schemas
# --------------------------------------------------------------------------
class InfoRequest(BaseModel):
    url: str


class DownloadRequest(BaseModel):
    url: str
    format_id: str
    mode: Literal["video", "audio"]
    bitrate: str | None = None


# --------------------------------------------------------------------------
# metadata
# --------------------------------------------------------------------------
async def _extract(url: str) -> tuple[dict, list[str]]:
    try:
        return await asyncio.to_thread(engine.extract, url)
    except engine.EngineError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/info")
async def post_info(payload: InfoRequest):
    url = engine.normalize_url(payload.url)
    if not url:
        raise HTTPException(status_code=400, detail="INVALID TARGET // EXPECTED youtube.com | youtu.be | VIDEO ID")
    info, warnings = await _extract(url)
    body = engine.describe(info, warnings)
    body["resolved_url"] = url
    return body


@app.get("/api/info")
async def get_info(url: str = Query(...)):
    normalized = engine.normalize_url(url)
    if not normalized:
        raise HTTPException(status_code=400, detail="INVALID TARGET // EXPECTED youtube.com | youtu.be | VIDEO ID")
    info, warnings = await _extract(normalized)
    body = engine.describe(info, warnings)
    body["resolved_url"] = normalized
    return body


# --------------------------------------------------------------------------
# download jobs
# --------------------------------------------------------------------------
@app.post("/api/download")
async def post_download(payload: DownloadRequest):
    url = engine.normalize_url(payload.url)
    if not url:
        raise HTTPException(status_code=400, detail="INVALID TARGET // EXPECTED youtube.com | youtu.be | VIDEO ID")

    info, warnings = await _extract(url)
    try:
        plan = engine.resolve_plan(info, payload.mode, payload.format_id, payload.bitrate)
    except engine.EngineError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    job = manager.create(
        url=url,
        title=str(info.get("title") or "UNTITLED TARGET"),
        mode=payload.mode,
        plan=plan,
        loop=asyncio.get_running_loop(),
    )
    manager.start_worker(job)
    return {
        "job_id": job.id,
        "status": job.status,
        "ws_url": f"/ws/download/{job.id}",
        "status_url": f"/api/download/{job.id}",
        "file_url": f"/api/file/{job.id}",
        "label": plan.get("label"),
        "estimated_bytes": plan.get("est_bytes"),
        "warnings": warnings,
    }


@app.get("/api/download/{job_id}")
async def job_status(job_id: str):
    job = manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="UNKNOWN JOB ID // SESSION EXPIRED OR NEVER EXISTED")
    return JSONResponse(job.snapshot())


@app.delete("/api/download/{job_id}")
async def cancel_job(job_id: str):
    job = manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="UNKNOWN JOB ID")
    job.cancel.set()
    if job.status not in TERMINAL_STATUSES:
        job.status = "cancelled"
        job.publish({"type": "cancelled"})
    shutil.rmtree(manager.base_dir / job_id, ignore_errors=True)
    return {"ok": True, "job_id": job_id}


@app.get("/api/file/{job_id}")
async def download_file(job_id: str):
    job = manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="UNKNOWN JOB ID")
    if job.status != "finished" or not job.filepath:
        raise HTTPException(status_code=409, detail="ARTIFACT NOT READY // WAIT FOR TRANSFER COMPLETE")
    path = Path(job.filepath)
    if not path.is_file():
        raise HTTPException(status_code=410, detail="ARTIFACT PURGED // RE-RUN THE EXTRACTION")
    return FileResponse(path, filename=job.filename or path.name, media_type="application/octet-stream")


# --------------------------------------------------------------------------
# websocket progress (long-poll fallback: GET /api/download/{id})
# --------------------------------------------------------------------------
@app.websocket("/ws/download/{job_id}")
async def ws_download(websocket: WebSocket, job_id: str):
    job = manager.get(job_id)
    if job is None:
        await websocket.close(code=4404)
        return
    await websocket.accept()
    queue = job.subscribe()
    try:
        snapshot = job.snapshot()
        await websocket.send_json(snapshot)
        if snapshot["status"] in TERMINAL_STATUSES:
            return
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=15)
            except asyncio.TimeoutError:
                await websocket.send_json({"type": "ping", "ts": time.time()})
                continue
            await websocket.send_json(event)
            if event.get("type") in ("done", "error", "cancelled"):
                break
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        job.unsubscribe(queue)


# --------------------------------------------------------------------------
# ops
# --------------------------------------------------------------------------
@app.get("/api/health")
async def health():
    return {
        "status": "online",
        "ffmpeg": engine.FFMPEG_AVAILABLE,
        "ffmpeg_version": engine.FFMPEG_VERSION,
        "ffmpeg_path": engine.FFMPEG_DIR,
        "node": engine.NODE_AVAILABLE,
        "yt_dlp": engine.yt_dlp.version.__version__,
        "engine_ready": engine.ENGINE_READY,
        "active_jobs": manager.count_active(),
    }


if FRONTEND_DIST.is_dir():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIST), html=True), name="frontend")
