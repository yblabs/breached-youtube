"""Download job bookkeeping: worker threads, event bus, snapshots."""

from __future__ import annotations

import asyncio
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from . import engine

TERMINAL_STATUSES = {"finished", "error", "cancelled"}


class Job:
    def __init__(self, *, job_id: str, url: str, title: str, mode: str, plan: dict, loop: asyncio.AbstractEventLoop) -> None:
        self.id = job_id
        self.url = url
        self.title = title or "UNTITLED TARGET"
        self.mode = mode
        self.plan = plan
        self.status = "queued"
        self.percent = 0.0
        self.downloaded = 0
        self.total = int(plan.get("est_bytes") or 0)
        self.speed: float | None = None
        self.eta: int | None = None
        self.logs: list[str] = []
        self.filename: str | None = None
        self.filepath: str | None = None
        self.filesize: int = 0
        self.error: str | None = None
        self.label = plan.get("label") or ""
        self.created = time.time()
        self.cancel = threading.Event()
        self._loop = loop
        self._queues: list[asyncio.Queue] = []

    # -- pub/sub ------------------------------------------------------
    def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
        self._queues.append(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        if queue in self._queues:
            self._queues.remove(queue)

    def publish(self, event: dict) -> None:
        """Thread safe: called from the yt-dlp worker thread."""
        if event.get("type") == "log":
            self.logs.append(str(event.get("text") or ""))
            if len(self.logs) > 400:
                del self.logs[:150]
        for queue in list(self._queues):
            try:
                asyncio.run_coroutine_threadsafe(queue.put(event), self._loop)
            except RuntimeError:
                continue

    def log(self, text: str) -> None:
        self.publish({"type": "log", "text": text})

    def snapshot(self) -> dict:
        return {
            "type": "snapshot",
            "job_id": self.id,
            "status": self.status,
            "percent": round(self.percent, 1),
            "downloaded": self.downloaded,
            "total": self.total,
            "speed": self.speed,
            "eta": self.eta,
            "mode": self.mode,
            "label": self.label,
            "title": self.title,
            "logs": list(self.logs),
            "filename": self.filename,
            "filesize": self.filesize,
            "error": self.error,
            "download_url": f"/api/file/{self.id}" if self.status == "finished" else None,
        }


class JobManager:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._jobs: dict[str, Job] = {}
        self._task: asyncio.Task | None = None

    # -- lifecycle ----------------------------------------------------
    def start(self) -> None:
        self.purge(max_age=0)
        self._task = asyncio.create_task(self._cleanup_loop())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(300)
            self.purge(max_age=1800)

    def purge(self, max_age: int = 1800) -> None:
        now = time.time()
        stale = [jid for jid, job in self._jobs.items() if now - job.created > max_age and job.status in TERMINAL_STATUSES]
        for jid in stale:
            self._jobs.pop(jid, None)
        for entry in self.base_dir.iterdir() if self.base_dir.exists() else []:
            if not entry.is_dir():
                continue
            try:
                age = now - entry.stat().st_mtime
            except OSError:
                continue
            if age > max_age:
                shutil.rmtree(entry, ignore_errors=True)

    # -- jobs ---------------------------------------------------------
    def create(self, *, url: str, title: str, mode: str, plan: dict, loop: asyncio.AbstractEventLoop) -> Job:
        job_id = uuid.uuid4().hex[:10].upper()
        job = Job(job_id=job_id, url=url, title=title, mode=mode, plan=plan, loop=loop)
        self._jobs[job_id] = job
        return job

    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    def count_active(self) -> int:
        return sum(1 for job in self._jobs.values() if job.status not in TERMINAL_STATUSES)

    def workdir(self, job_id: str) -> Path:
        path = self.base_dir / job_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def start_worker(self, job: Job) -> None:
        workdir = str(self.workdir(job.id))
        thread = threading.Thread(target=_worker, args=(job, workdir), daemon=True, name=f"grab-{job.id}")
        thread.start()


def _worker(job: Job, workdir: str) -> None:
    try:
        engine_path_note = engine.FFMPEG_DIR or "NOT FOUND"
        job.log("[SYS.BOOT] BREACHED YOUTUBE EXTRACTION NODE ONLINE")
        job.log(f"[SYS.MSG] TARGET LOCKED // {job.title[:120]}")
        job.log(f"[SYS.MSG] MODE={job.mode.upper()} // CONTAINER={job.plan.get('container', '?').upper()} // FFMPEG={engine_path_note}")
        for stream in job.plan.get("streams", []):
            job.log(f"[NET.OK] {stream['role'].upper()} STREAM RESOLVED // {stream['label']} // ID={stream['id']}")
        job.log("[SYS.MSG] DOWNLOADING PACKETS... 0%")
        job.status = "downloading"
        job.publish({"type": "status", "status": "downloading"})

        path, filename, size = engine.run_download(
            job.url,
            job.plan,
            workdir,
            job.publish,
            should_cancel=job.cancel.is_set,
        )

        job.status = "finished"
        job.percent = 100.0
        job.filepath = path
        job.filename = filename
        job.filesize = size
        job.speed = None
        job.eta = None
        job.log(f"[OK] TRANSFER COMPLETE // {filename} // {engine.human_size(size)}")
        job.publish(
            {
                "type": "done",
                "status": "finished",
                "filename": filename,
                "size": size,
                "download_url": f"/api/file/{job.id}",
                "percent": 100.0,
            }
        )
    except engine.DownloadAborted:
        job.status = "cancelled"
        job.log("[WARN] TRANSFER ABORTED BY OPERATOR")
        job.publish({"type": "cancelled", "status": "cancelled"})
    except engine.EngineError as exc:
        job.status = "error"
        job.error = str(exc)
        job.log(f"[ERR] {exc}")
        job.publish({"type": "error", "status": "error", "error": str(exc)})
    except Exception as exc:  # pragma: no cover - safety net
        job.status = "error"
        job.error = f"UNEXPECTED FAULT // {exc}"
        job.log(f"[ERR] UNEXPECTED FAULT // {exc}")
        job.publish({"type": "error", "status": "error", "error": job.error})
