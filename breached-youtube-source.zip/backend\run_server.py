"""Launch the BREACHED YOUTUBE API: python run_server.py"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, log_level="info")
